import { useState } from 'react';
import { LandingBaseline } from '@/components/landing-baseline';
import { Action, PageIntro, Panel, Row, Screen, Section, SessionRow, Sheet } from '@/components/monitoring-ui';
import { RangeChart } from '@/components/range-chart';
<<<<<<< HEAD
import { SelectionControl } from '@/components/selection-control';
=======
import { LandingBaseline } from '@/components/landing-baseline';
>>>>>>> main
import { ThemedText as Text } from '@/components/themed-text';
import { average, jointSessions, joints, observations, rom, type Activity } from '@/data/demo';

export default function TrendsScreen() {
  const [days, setDays] = useState('7');
  const [jointId, setJointId] = useState('right-knee');
  const [activity, setActivity] = useState('Running');
  const [qualityOpen, setQualityOpen] = useState(false);
  const joint = joints.find((item) => item.id === jointId)!;
<<<<<<< HEAD
  const landing = activity === 'Landings';
  const motionActivity = activity as Activity;
  const records = landing ? [] : observations(joint, motionActivity, Number(days));
  const previous = landing ? [] : observations(joint, motionActivity, Number(days), true);
  const current = average(records.map((session) => rom(joint, session)));
  const prior = average(previous.map((session) => rom(joint, session)));
  const excluded = jointSessions(joint).filter((session) => session.offset < Number(days)
    && session.activity === activity && session.coverage < 80).length;
  const activities = ['Running', 'Walking', ...(joint.anatomy === 'Knee' ? ['Landings'] : [])];
  return <>
    <Screen>
      <PageIntro title="Trends" />
=======
  const records = observations(joint, activity, days);
  const previous = observations(joint, activity, days, true);
  const currentRange = average(records.map((session) => rom(joint, session)));
  const previousRange = average(previous.map((session) => rom(joint, session)));
  const minutes = records.reduce((sum, session) => sum + session.minutes, 0);
  const previousMinutes = previous.reduce(
    (sum, session) => sum + session.minutes,
    0,
  );
  const baseline = reference(joint, activity);
  const hasReference = joint.baselineReady && baseline !== null;
  const excluded = jointSessions(joint).filter(
    (session) =>
      session.offset < days &&
      session.activity === activity &&
      session.coverage < 80,
  ).length;
  return (
    <Screen>
      <PageIntro
        title="See your patterns."
        description="Your movement, understood over time."
      />
      <LandingBaseline />
      <Text type="subtitle">Running & walking history</Text>
>>>>>>> main
      <Row wrap>
        <SelectionControl label="Joint" value={jointId} onChange={(value) => {
          setJointId(value);
          if (activity === 'Landings' && joints.find((item) => item.id === value)?.anatomy !== 'Knee') setActivity('Running');
        }} options={joints.filter((item) => item.monitored).map((item) => ({ value: item.id, label: item.name }))} />
        <SelectionControl label="Activity" value={activity} onChange={setActivity}
          options={activities.map((value) => ({ value, label: value }))} />
      </Row>
      {landing ? <LandingBaseline mode="summary" initialSide={joint.id.startsWith('left') ? 'left' : 'right'} key={joint.id} /> : <>
        <SelectionControl label="Period" value={days} onChange={setDays}
          options={[{ value: '7', label: 'Past week' }, { value: '30', label: 'Past month' }]} />
        <Panel>
          <RangeChart key={`${jointId}-${activity}-${days}`} joint={joint} activity={motionActivity} records={records} />
          {current !== null && prior !== null ? <Text type="small">
            {Math.abs(current - prior).toFixed(1)}° {current >= prior ? 'higher' : 'lower'} than the previous {days} days.
          </Text> : null}
        </Panel>
        <Row wrap>
          <Text type="small" themeColor="textSecondary">{records.length} recordings{excluded ? ` · ${excluded} excluded` : ''}</Text>
          <Action onPress={() => setQualityOpen(true)}>Recording details</Action>
        </Row>
<<<<<<< HEAD
        {records.length ? <Section title="Recent recordings">
          {records.slice(0, 3).map((session) => <SessionRow key={session.id} session={session} />)}
        </Section> : null}
      </>}
=======
        <RangeChart
          key={`${jointId}-${activity}-${days}`}
          joint={joint}
          activity={activity}
          records={records}
        />
      </Panel>
      {records.length ? (
        <>
          <Section title="Activity exposure">
            <Row wrap>
              <Metric
                label="Activity duration"
                value={String(minutes)}
                unit="min"
                detail={`Total duration of ${records.length} comparable ${activity.toLowerCase()} recordings for the ${joint.name.toLowerCase()}. Recordings below 80% valid coverage are excluded. This is a duration summary, not a tissue-load measurement.`}
              />
              <Metric
                label="Movement cycles"
                value={records
                  .reduce((sum, session) => sum + session.cycles, 0)
                  .toLocaleString()}
                detail="Counted movement cycles in the selected recordings. Detection rules depend on the activity and sensor setup; a cycle is not a force measurement."
              />
            </Row>
          </Section>
          <Section title="What changed?">
            <Panel>
              <Text type="label" style={{ color: c.accent }}>
                Movement pattern
              </Text>
              <Text type="subtitle">
                {hasReference
                  ? currentRange! >= baseline.low &&
                    currentRange! <= baseline.high
                    ? 'Your range stayed close to your reference.'
                    : 'Your range differs from your reference.'
                  : 'No learned reference for this activity yet.'}
              </Text>
              <Text type="small" themeColor="textSecondary">
                {hasReference
                  ? `${Math.round(currentRange!)}° average across ${records.length} comparable recordings. Your illustrative reference is ${baseline.low}–${baseline.high}° for ${activity.toLowerCase()} with the same placement.`
                  : `${records.length} comparable demo recordings. Landing reference values are not used for ${activity.toLowerCase()}.`}
              </Text>
              {previousRange !== null ? (
                <Text type="small">
                  {Math.abs(currentRange! - previousRange).toFixed(1)}°{' '}
                  {currentRange! >= previousRange ? 'higher' : 'lower'} than the
                  previous {days} days’ average.
                </Text>
              ) : (
                <Text type="small" themeColor="textSecondary">
                  No comparable recordings in the previous period.
                </Text>
              )}
            </Panel>
            {previous.length ? (
              <Panel>
                <Text type="label" style={{ color: c.accent }}>
                  Activity history
                </Text>
                <Text type="subtitle">
                  {Math.abs(minutes - previousMinutes)} min{' '}
                  {minutes >= previousMinutes ? 'more' : 'less'} recorded{' '}
                  {activity.toLowerCase()}.
                </Text>
                <Text type="small" themeColor="textSecondary">
                  {records.length} recordings in this period versus{' '}
                  {previous.length} in the previous {days} days. This describes
                  recorded exposure; more is not automatically better.
                </Text>
              </Panel>
            ) : null}
          </Section>
          <Text type="small" themeColor="textSecondary">
            {excluded
              ? `${excluded} recording excluded because of incomplete coverage. `
              : ''}
            Comparisons use the same joint, activity, and demo placement.
            Unrecorded activity is not included.
          </Text>
          <Section title="Compared recordings">
            {records.slice(0, days === 7 ? 4 : 8).map((session) => (
              <SessionRow key={session.id} session={session} />
            ))}
            {records.length > 8 ? (
              <Text type="small" themeColor="textSecondary">
                Showing the latest 8 recordings. All {records.length}{' '}
                measurements are available in “View data”.
              </Text>
            ) : null}
          </Section>
        </>
      ) : (
        <View style={{ gap: s.two }}>
          <Text type="subtitle">
            {joint.monitored
              ? 'No data for this selection'
              : 'This joint isn’t monitored yet'}
          </Text>
          <Text themeColor="textSecondary">
            {joint.monitored
              ? 'Try another activity or period.'
              : 'Choose a monitored joint to explore its history.'}
          </Text>
        </View>
      )}
      {records.length ? (
        <Text type="small" themeColor="textSecondary">
          Latest included observation · {formatDate(records[0].date)}
        </Text>
      ) : null}
>>>>>>> main
    </Screen>
    <Sheet title="Recording details" open={qualityOpen} onClose={() => setQualityOpen(false)}>
      <Text>{joint.name} · {activity} · past {days} days</Text>
      <Text type="small">Only recordings with at least 80% valid coverage are included. {excluded} excluded.</Text>
      <Text type="small" themeColor="textSecondary">No learned running or walking reference is available. Landing comparisons use a separate activity-specific reference. All data is synthetic.</Text>
      <Text type="small">{records.reduce((sum, session) => sum + session.minutes, 0)} min recorded · {records.reduce((sum, session) => sum + session.cycles, 0).toLocaleString()} movement cycles.</Text>
      {records.map((session) => <SessionRow key={session.id} session={session} />)}
    </Sheet>
  </>;
}
